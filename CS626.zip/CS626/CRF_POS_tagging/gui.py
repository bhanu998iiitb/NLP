import tkinter as tk
import nltk , re
nltk.download("brown")
nltk.download("universal_tagset")

import random
import numpy as np
import pandas as pd
import seaborn as sns
from nltk.corpus import brown
from collections import defaultdict
from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, confusion_matrix
import sklearn
import sklearn_crfsuite
from sklearn_crfsuite import metrics
from sklearn_crfsuite import scorers
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
sns.set_theme()

def load():
    data = brown.tagged_sents(tagset = "universal") 
    data = list(data)
    return data

data = load()

# extract features from a given sentence
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def word2features(sent, i):
    word = sent[i][0]

    features = {
        'bias': 1.0,
        'word': word,
        'len(word)': len(word),
        'word[:4]': word[:4],
        'word[:3]': word[:3],
        'word[:2]': word[:2],
        'word[-3:]': word[-3:],
        'word[-2:]': word[-2:],
        'word[-4:]': word[-4:],
        'word.lower()': word.lower(),
        'word.stemmed': re.sub(r'(.{2,}?)([aeiougyn]+$)',r'\1', word.lower()),
        'word.isdigit()': word.isdigit(),
    }
    if i > 0:
        word1 = sent[i-1][0]
        features.update({
            '-1:word': word1,
            '-1:len(word)': len(word1),
            '-1:word.lower()': word1.lower(),
            '-1:word.stemmed': re.sub(r'(.{2,}?)([aeiougyn]+$)',r'\1', word1.lower()),
            '-1:word[:3]': word1[:3],
            '-1:word[:2]': word1[:2],
            '-1:word[-3:]': word1[-3:],
            '-1:word[-2:]': word1[-2:],
            '-1:word.isdigit()': word1.isdigit(),

        })
    else:
        features['BOS'] = True

    if i > 1:
        word2 = sent[i-2][0]
        features.update({
            '-2:word': word2,
            '-2:len(word)': len(word2),
            '-2:word.lower()': word2.lower(),
            '-2:word[:3]': word2[:3],
            '-2:word[:2]': word2[:2],
            '-2:word[-3:]': word2[-3:],
            '-2:word[-2:]': word2[-2:],
            '-2:word.isdigit()': word2.isdigit(),

        })

    if i < len(sent)-1:
        word1 = sent[i+1][0]
        features.update({
            '+1:word': word1,
            '+1:len(word)': len(word1),
            '+1:word.lower()': word1.lower(),
            '+1:word[:3]': word1[:3],
            '+1:word[:2]': word1[:2],
            '+1:word[-3:]': word1[-3:],
            '+1:word[-2:]': word1[-2:],
            '+1:word.isdigit()': word1.isdigit(),

        })

    else:
        features['EOS'] = True

    if i < len(sent) - 2:
        word2 = sent[i+2][0]
        features.update({
            '+2:word': word2,
            '+2:len(word)': len(word2),
            '+2:word.lower()': word2.lower(),
            '+2:word.stemmed': re.sub(r'(.{2,}?)([aeiougyn]+$)',r'\1', word2.lower()),
            '+2:word[:3]': word2[:3],
            '+2:word[:2]': word2[:2],
            '+2:word[-3:]': word2[-3:],
            '+2:word[-2:]': word2[-2:],
            '+2:word.isdigit()': word2.isdigit(),

        })

    return features



# defining a few more functions to extract featrues, postags and words from sentences

def data2features(data):
    return [word2features(data, i) for i in range(len(data))]

def data2labels(data):
    return [postag for word, postag in data]

# def data2tokens(data):
#     return [word for word, postag in data]    

X_train = [data2features(s) for s in data]
y_train = [data2labels(s) for s in data]

print(X_train[0][0:10])
print(y_train[0][0:10])

# fitting crf with arbitrary hyperparameters
crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=0.01,
    c2=0.1,
    max_iterations=100,
    all_possible_transitions=True   
)
crf.fit(X_train, y_train)

test = ['This', 'is', 'a', 'bag']
print(crf.predict([data2features(test)]))

def display_words():
    # Get the input sentence from the entry widget
    sentence = entry.get()
    words = list(sentence.split())
    # sentence = "- " + sentence
    features = data2features(words)
    
    # Clear the text widget
    text_output.delete(1.0, tk.END)

    # Call the viterbi function to get the tags
    tags = process_input(features)
    
    # Display the tags
    for word, tag in zip(words, tags[0]):
        text_output.insert(tk.END, f"{word}: {tag}\n")

def process_input(s):
    tags = []
    tags = crf.predict([s])
    
    return tags

def on_enter(event):
    button.invoke()  # Simulate a button click

def update_sizes(event):
    # Get the current window size
    window_width = root.winfo_width()
    window_height = root.winfo_height()
    
    # Calculate font size as a percentage of the window width
    font_size = int(window_width * 0.02)  # Adjust this percentage as needed
    
    # Update the font size for the label and button
    label.config(font=("Arial", font_size))
    button.config(font=("Arial", font_size))
    
    # Calculate Entry and Text widget sizes
    entry_width = int(window_width * 0.7)  # 70% of window width
    entry_height = int(window_height * 0.1)  # 10% of window height
    
    text_height = int(window_height * 0.5)  # 50% of window height

    # Update the size of the Entry widget
    entry.config(width=entry_width, font=("Arial", font_size))
    
    # Update the size of the Text widget
    text_output.config(height=text_height, font=("Arial", font_size))

# Create the main window
root = tk.Tk()
root.title("Sentence POS Tagger")

# Set initial window size
root.geometry("600x400")

label_color = "red"
button_color = "red"

# Create an entry widget for user input
label = tk.Label(root, text="Enter a sentence:", font=("Arial", 14), fg=label_color)
label.pack(fill=tk.BOTH, padx=10, pady=10)

entry = tk.Entry(root)
entry.pack(fill=tk.BOTH, padx=10, pady=10)
# Bind the Enter key to the on_enter function
entry.bind("<Return>", on_enter)

# Create a button to trigger the word display
button = tk.Button(root, text="Show Words", command=display_words, font=("Arial", 14), fg="white", bg=button_color)
button.pack(padx=10, pady=10)

# Create a text widget to display the words
text_output = tk.Text(root)
text_output.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

# Bind the resize event to update sizes
root.bind("<Configure>", update_sizes)

root.mainloop()


