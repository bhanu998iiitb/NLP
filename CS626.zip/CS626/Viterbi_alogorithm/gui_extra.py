import tkinter as tk
from main import *

def display_words():
    # Get the input sentence from the entry widget
    sentence = entry.get()
    # Split the sentence into words
    words = list(sentence.split())
    
    # Clear the text widget
    text_output.delete(1.0, tk.END)
    # Insert each word in a new line
    for word in words:
        text_output.insert(tk.END, word + '\n')

def on_enter(event):
    button.invoke()  # Simulate a button click

def update_sizes(event):
    # Get the current window size
    window_width = root.winfo_width()
    window_height = root.winfo_height()
    
    # Calculate font size as a percentage of the window width
    font_size = int(window_width * 0.02)  # Adjust this percentage as needed
    
    # Update the font size for the label and button
    label.config(font=("Arial", font_size))
    button.config(font=("Arial", font_size))
    
    # Calculate Entry and Text widget sizes
    entry_width = int(window_width * 0.7)  # 70% of window width
    entry_height = int(window_height * 0.1)  # 10% of window height
    
    text_height = int(window_height * 0.5)  # 50% of window height

    # Update the size of the Entry widget
    entry.config(width=entry_width, font=("Arial", font_size))
    
    # Update the size of the Text widget
    text_output.config(height=text_height, font=("Arial", font_size))

# Create the main window
root = tk.Tk()
root.title("Sentence Word Splitter")

# Set initial window size
root.geometry("600x400")

label_color = "red"
button_color = "red"

# Create an entry widget for user input
label = tk.Label(root, text="Enter a sentence:", font=("Arial", 14), fg=label_color)
label.pack(fill=tk.BOTH, padx=10, pady=10)

entry = tk.Entry(root)
entry.pack(fill=tk.BOTH, padx=10, pady=10)
# Bind the Enter key to the on_enter function
entry.bind("<Return>", on_enter)

# Create a button to trigger the word display
button = tk.Button(root, text="Show Words", command=display_words, font=("Arial", 14), fg="white", bg=button_color)
button.pack(padx=10, pady=10)

# Create a text widget to display the words
text_output = tk.Text(root)
text_output.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

# Bind the resize event to update sizes
root.bind("<Configure>", update_sizes)

# Run the application
root.mainloop()