import tkinter as tk
import nltk
nltk.download("brown")
nltk.download("universal_tagset")

import random
import numpy as np
import pandas as pd
import seaborn as sns
from nltk.corpus import brown
from collections import defaultdict
from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, confusion_matrix
sns.set_theme()

SEED = 0

def setSeed(seed):
    np.random.seed(seed)
    random.seed(seed)

setSeed(SEED) 

mean = lambda l : sum(l) / len(l) 

def log(x):
    if x == 0:
        return -np.inf
    else:
        return np.log(x)


def load():
    data = brown.tagged_sents(tagset = "universal") 
    data = list(data)
    return data

def preprocess(data):
    for s in data:
        s.insert(0, ("^", "-")) # '^' for sentence, '-' for tag

def createFolds(data, k):
    n = len(data)
    n_split = n // k 
    random.shuffle(data)
    folds = []
    for start in range(0, n, n_split):
        end = min(start + n_split, n)
        fold = data[start : end]
        folds.append(fold)
    return folds

def getSentence(d):
    s = " ".join([i[0] for i in d])
    return s

def getTags(d):
    t = " ".join([i[1] for i in d])
    return t

def buildTags(data):
    tags = set()
    for s in data:
        for w, t in s:
            tags.add(t)
    tags = sorted(list(tags))
    return tags

def buildVocab(data):
    vocab = set()
    for s in data:
        for w, t in s:
            vocab.add(w)
    vocab = sorted(list(vocab))
    return vocab

def buildFreqs(data):
    tf = defaultdict(int) 
    ef = defaultdict(int)
    tag_freq = defaultdict(int)

    for s in data:
        p = "-" # the initial value of the previous tag (this acts as the tag for ^: the sentence start)
        for w, t in s:
            tf[(p, t)] += 1 # auto-init to 0 when key doesn't exit
            ef[(t, w)] += 1 # each word has a corresponding tag
            tag_freq[t] += 1
            p = t # update prev tag

    return tf, ef, tag_freq

def buildMatrices(tf, ef, tag_freq,N_TAGS,N_VOCAB):
    tm = np.zeros((N_TAGS, N_TAGS))
    em = np.zeros((N_TAGS, N_VOCAB))

    alpha = 1e-8
    # print(1)
    for i in range(N_TAGS):

        for j in range(N_TAGS):
            ti = id2tag(i)
            tj = id2tag(j)
            tm[i, j] = (tf[(ti, tj)] + alpha) / (tag_freq[ti] + alpha*N_TAGS)

        for j in range(N_VOCAB):
            ti = id2tag(i)
            wj = id2word(j)
            em[i, j] = (ef[(ti, wj)] + alpha) / (tag_freq[ti] + alpha*N_VOCAB)

    return tm, em

def train(data):
    tf, ef, tag_freq = buildFreqs(data)
    tm, em = buildMatrices(tf, ef, tag_freq,N_TAGS,N_VOCAB)
    return tm, em

def viterbi(tm, em, s):

    n_sent = len(s) 
    
    best_probs = np.zeros((n_sent, N_TAGS)) 
    best_tags  = np.zeros((n_sent, N_TAGS))

    for i in range(N_TAGS):
        best_probs[0, i] = log(tm[0, i]) + log(em[i, word2id(s[0])])

    
    for i in range(1, n_sent):

        w_prev = s[i - 1]
        w = s[i]

        for j in range(N_TAGS):
            pmax = -np.inf
            best_tag = None # stores index of the best tag for the current word
            for k in range(N_TAGS):        
                p = best_probs[i - 1, k] + log(tm[k, j])
                if p > pmax:
                    pmax = p
                    best_tag = k

            try:
                wid = word2id(w)
            except KeyError: 
                wid = -1 

            if wid != -1:
                best_probs[i, j] = pmax + log(em[j, wid]) 
            else:
                best_probs[i, j] = pmax + log(em.min()) 

            best_tags[i, j] = best_tag

    pred = [] 

    # Get the last tag 
    pmax = -np.inf
    end_tag = None
    for i in range(N_TAGS):
        if best_probs[-1, i] > pmax:
            pmax = best_probs[-1, i]
            end_tag = i
    pred.append(end_tag)


    t = end_tag # init
    for i in range(n_sent - 1, 1, -1):
        t = int(best_tags[i, t])
        pred.append(t)

    pred.reverse() # as we have built this starting from the back

    return pred

data = load()
preprocess(data)

TAGS = buildTags(data)
N_TAGS = len(TAGS)
VOCAB = buildVocab(data)
N_VOCAB = len(VOCAB)

id2tag = lambda i : TAGS[i]
tagmap = {TAGS[i]:i for i in range(N_TAGS)}
tag2id = lambda i : tagmap[i]

id2word = lambda i : VOCAB[i]
wordmap = {VOCAB[i]:i for i in range(N_VOCAB)}
word2id = lambda i : wordmap[i]

tm, em = train(data)

print(tm)
print(em)

def evaluate(d, tm, em):
    # Evaluates the trained HMM model on the data
    tags_pred = []
    t_pred = viterbi(tm, em, d)
    tags = []
    tags_pred += t_pred
    for i in t_pred:
        tags.append(id2tag(i))
        
    return tags


def display_words():
    # Get the input sentence from the entry widget
    sentence = entry.get()
    words = list(sentence.split())
    sentence = "- " + sentence
    
    # Clear the text widget
    text_output.delete(1.0, tk.END)

    # Call the viterbi function to get the tags
    tags = process_input(sentence)
    
    # Display the tags
    for word, tag in zip(words, tags):
        text_output.insert(tk.END, f"{word}: {tag}\n")

def process_input(s):
    tags = []
    print(viterbi(tm, em, s.split()))
    for i in viterbi(tm, em, s.split()):
      tags.append(id2tag(i))

    
    return tags

def on_enter(event):
    button.invoke()  # Simulate a button click

def update_sizes(event):
    # Get the current window size
    window_width = root.winfo_width()
    window_height = root.winfo_height()
    
    # Calculate font size as a percentage of the window width
    font_size = int(window_width * 0.02)  # Adjust this percentage as needed
    
    # Update the font size for the label and button
    label.config(font=("Arial", font_size))
    button.config(font=("Arial", font_size))
    
    # Calculate Entry and Text widget sizes
    entry_width = int(window_width * 0.7)  # 70% of window width
    entry_height = int(window_height * 0.1)  # 10% of window height
    
    text_height = int(window_height * 0.5)  # 50% of window height

    # Update the size of the Entry widget
    entry.config(width=entry_width, font=("Arial", font_size))
    
    # Update the size of the Text widget
    text_output.config(height=text_height, font=("Arial", font_size))

# Create the main window
root = tk.Tk()
root.title("Sentence POS Tagger")

# Set initial window size
root.geometry("600x400")

label_color = "red"
button_color = "red"

# Create an entry widget for user input
label = tk.Label(root, text="Enter a sentence:", font=("Arial", 14), fg=label_color)
label.pack(fill=tk.BOTH, padx=10, pady=10)

entry = tk.Entry(root)
entry.pack(fill=tk.BOTH, padx=10, pady=10)
# Bind the Enter key to the on_enter function
entry.bind("<Return>", on_enter)

# Create a button to trigger the word display
button = tk.Button(root, text="Show Words", command=display_words, font=("Arial", 14), fg="white", bg=button_color)
button.pack(padx=10, pady=10)

# Create a text widget to display the words
text_output = tk.Text(root)
text_output.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

# Bind the resize event to update sizes
root.bind("<Configure>", update_sizes)

root.mainloop()


