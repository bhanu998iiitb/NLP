# Download the required data (run this only once)
import nltk
nltk.download("brown")
nltk.download("universal_tagset")

# %reset -f

import random
import numpy as np
import pandas as pd
import seaborn as sns
from nltk.corpus import brown
# from tqdm import tqdm
from collections import defaultdict
from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, fbeta_score, confusion_matrix
sns.set_theme()

SEED = 0

def setSeed(seed):
    np.random.seed(seed)
    random.seed(seed)

setSeed(SEED) 

mean = lambda l : sum(l) / len(l) 

def log(x):
    if x == 0:
        return -np.inf
    else:
        return np.log(x)

def plotCM(cm):
    df_cm = pd.DataFrame(cm, index = [t for t in TAGS[1:]], columns = [t for t in TAGS[1:]])
    plt.figure(figsize = (15, 10))
    sns.heatmap(df_cm, annot = True, cmap = plt.cm.Reds)
    plt.show()

def printClasswise(metrics):
    for i in range(N_TAGS - 1):
        print(f"{TAGS[i+1]}: {metrics[i]:.3f}", end = ", ")
    print()

def load():
    data = brown.tagged_sents(tagset = "universal") 
    data = list(data)
    return data

def preprocess(data):
    for s in data:
        s.insert(0, ("^", "-")) # '^' for sentence, '-' for tag

def createFolds(data, k):
    n = len(data)
    n_split = n // k 
    random.shuffle(data)
    folds = []
    for start in range(0, n, n_split):
        end = min(start + n_split, n)
        fold = data[start : end]
        folds.append(fold)
    return folds

def getSentence(d):
    s = " ".join([i[0] for i in d])
    return s

def getTags(d):
    t = " ".join([i[1] for i in d])
    return t

def buildTags(data):
    tags = set()
    for s in data:
        for w, t in s:
            tags.add(t)
    tags = sorted(list(tags))
    return tags

def buildVocab(data):
    vocab = set()
    for s in data:
        for w, t in s:
            vocab.add(w)
    vocab = sorted(list(vocab))
    return vocab

def buildFreqs(data):
    tf = defaultdict(int) 
    ef = defaultdict(int)
    tag_freq = defaultdict(int)

    for s in data:
        p = "-" # the initial value of the previous tag (this acts as the tag for ^: the sentence start)
        for w, t in s:
            tf[(p, t)] += 1 # auto-init to 0 when key doesn't exit
            ef[(t, w)] += 1 # each word has a corresponding tag
            tag_freq[t] += 1
            p = t # update prev tag

    return tf, ef, tag_freq

def buildMatrices(tf, ef, tag_freq,N_TAGS,N_VOCAB):
    tm = np.zeros((N_TAGS, N_TAGS))
    em = np.zeros((N_TAGS, N_VOCAB))

    alpha = 1e-8

    for i in range(N_TAGS):

        for j in range(N_TAGS):
            ti = id2tag(i)
            tj = id2tag(j)
            tm[i, j] = (tf[(ti, tj)] + alpha) / (tag_freq[ti] + alpha*N_TAGS)

        for j in range(N_VOCAB):
            ti = id2tag(i)
            wj = id2word(j)
            em[i, j] = (ef[(ti, wj)] + alpha) / (tag_freq[ti] + alpha*N_VOCAB)

    return tm, em

def train(data):
    tf, ef, tag_freq = buildFreqs(data)
    tm, em = buildMatrices(tf, ef, tag_freq,N_TAGS,N_VOCAB)
    return tm, em

def viterbi(tm, em, s):

    n_sent = len(s) 

    best_probs = np.zeros((n_sent, N_TAGS)) 
    best_tags  = np.zeros((n_sent, N_TAGS))

    for i in range(N_TAGS):
        best_probs[0, i] = log(tm[0, i]) + log(em[i, word2id(s[0])])

    
    for i in range(1, n_sent):

        w_prev = s[i - 1]
        w = s[i]

        for j in range(N_TAGS):
            pmax = -np.inf
            best_tag = None # stores index of the best tag for the current word
            for k in range(N_TAGS):        
                p = best_probs[i - 1, k] + log(tm[k, j])
                if p > pmax:
                    pmax = p
                    best_tag = k

            try:
                wid = word2id(w)
            except KeyError: 
                wid = -1 

            if wid != -1:
                best_probs[i, j] = pmax + log(em[j, wid]) 
            else:
                best_probs[i, j] = pmax + log(em.min()) 

            best_tags[i, j] = best_tag

    pred = [] 

    # Get the last tag 
    pmax = -np.inf
    end_tag = None
    for i in range(N_TAGS):
        if best_probs[-1, i] > pmax:
            pmax = best_probs[-1, i]
            end_tag = i
    pred.append(end_tag)


    t = end_tag # init
    for i in range(n_sent - 1, 1, -1):
        t = int(best_tags[i, t])
        pred.append(t)

    pred.reverse() # as we have built this starting from the back

    return pred

def evaluate(data, tm, em):
    # Evaluates the trained HMM model on the data

    tags_true = []
    tags_pred = []

    for d in data:
        s = [i[0] for i in d]
        t_true = [tag2id(i[1]) for i in d[1:]] # ignoring "-" at the start
        t_pred = viterbi(tm, em, s)
        tags_true += t_true
        tags_pred += t_pred
        
    return tags_true, tags_pred

if __name__ == "__main__":
    # Load the required data
    data = load()
    preprocess(data)

    N = len(data)
    print(f"Length: {N:,}")

    TAGS = buildTags(data)
    N_TAGS = len(TAGS)
    print(f"Tagset size: {N_TAGS} (includes the dummy '-' tag)")
    print(TAGS)

    # Maps
    id2tag = lambda i : TAGS[i]
    tagmap = {TAGS[i]:i for i in range(N_TAGS)}
    tag2id = lambda i : tagmap[i]

    # Print some random statements and the corresponding tags
    for i in random.sample(range(N), 5):
        print(getSentence(data[i]))
        print(getTags(data[i]))
        print()

    folds = createFolds(data, k = 5)

    # Initialize the metrics

    # Avg cm
    avg_cm = 0 # ignoring the dummy tag added at the start of each sentence

    # Initialize average metrics
    avg_acc = 0
    avg_prec = 0
    avg_rec = 0
    avg_f1 = 0
    avg_f05 = 0
    avg_f2 = 0

    # Average tagwise metrics
    avg_prec_tagwise = 0
    avg_rec_tagwise = 0
    avg_f1_tagwise = 0

    # Start cross-validation

    for fv in range(5):

        # Separate out the validation fold
        val_data = folds[fv]

        # Concatenate the training folds
        train_data = []
        for ft in range(5):
            if ft != fv:
                train_data += folds[ft]

        # Update vocab based on training data (these variables are used globally)
        VOCAB = buildVocab(train_data)
        N_VOCAB = len(VOCAB)
        id2word = lambda i : VOCAB[i]
        wordmap = {VOCAB[i]:i for i in range(N_VOCAB)}
        word2id = lambda i : wordmap[i]

        # Train
        tm, em = train(train_data)

        # Validate
        tags_true, tags_pred = evaluate(val_data, tm, em)

        # Compute metrics

        metric_labels = [i+1 for i in range(N_TAGS - 1)] # ignore the first dummy tag '-'

        cm = confusion_matrix(tags_true, tags_pred, normalize = "true", labels = metric_labels)
        acc = accuracy_score(tags_true, tags_pred)

        prec = precision_score(tags_true, tags_pred, average = None, labels = metric_labels)
        rec = recall_score(tags_true, tags_pred, average = None, labels = metric_labels)
        f1 = f1_score(tags_true, tags_pred, average = None, labels = metric_labels)

        f05 = fbeta_score(tags_true, tags_pred, beta = 0.5, average = "macro", labels = metric_labels)
        f2 = fbeta_score(tags_true, tags_pred, beta = 2, average = "macro", labels = metric_labels)

        # Tag-wise metrics
        print("Tag-wise precision:")
        printClasswise(prec)

        print("Tag-wise recall:")
        printClasswise(rec)

        print("Tag-wise F1:")
        printClasswise(f1)

        # Overall metrics for this fold
        print("Accuracy:", acc)
        print("Avg. precision:", mean(prec))
        print("Avg. recall:", mean(rec))
        print("Avg. f_0.5:", f05)
        print("Avg. f1:", mean(f1))
        print("Avg. f2:", f2)

        plotCM(cm)

        # Update global avg values
        avg_acc += acc
        avg_prec += mean(prec)
        avg_rec += mean(rec)
        avg_f1 += mean(f1)
        avg_f05 += f05
        avg_f2 += f2

        # Update tagwise metrics
        avg_prec_tagwise += prec
        avg_rec_tagwise += rec
        avg_f1_tagwise += f1

        # Update cm
        avg_cm += cm

    # Average over the number of folds

    avg_cm /= 5

    avg_acc /= 5
    avg_prec /= 5
    avg_rec /= 5
    avg_f1 /= 5
    avg_f05 /= 5
    avg_f2 /= 5

    avg_prec_tagwise /= 5
    avg_rec_tagwise /= 5
    avg_f1_tagwise /= 5

    # Final metrics reported

    # Tag-wise metrics
    print("Tag-wise precision:")
    printClasswise(avg_prec_tagwise)

    print("Tag-wise recall:")
    printClasswise(avg_rec_tagwise)

    print("Tag-wise F1:")
    printClasswise(avg_f1_tagwise)

    # Overall metrics for this fold
    print("Accuracy:", avg_acc)
    print("Avg. precision:", avg_prec)
    print("Avg. recall:", avg_rec)
    print("Avg. f_0.5:", avg_f05)
    print("Avg. f1:", avg_f1)
    print("Avg. f2:", avg_f2)

    plotCM(avg_cm)
